# Performance Tweaks

These steps can help you get better FPS in PPSSPP:

1. Use **Vulkan** if available; fallback to **OpenGL** if unstable.
2. Keep rendering resolution low (1x PSP for low-end PCs).
3. Disable texture scaling and heavy shaders.
4. Set Frameskip to 0, VSync off for less input lag.
5. Use a High Performance power plan in Windows.
