# Controller Input Lag Tips

1. Use a wired controller instead of wireless for lower latency.
2. In PPSSPP, set `Control Mapping` to match your device exactly.
3. Disable VSync for faster input response.
