# Cheats and FPS Patches

Some PSP games need special patches to run at 60 FPS.

- Enable cheats in PPSSPP settings.
- Place `.ini` or `.txt` cheat files in the `PSP/CHEATS` folder.
- Search online for "[Game Name] 60fps PPSSPP cheat" to find them.
